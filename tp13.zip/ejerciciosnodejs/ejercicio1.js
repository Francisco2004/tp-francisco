console.log('Mi primer programa con Node.js');
console.log('Fin');